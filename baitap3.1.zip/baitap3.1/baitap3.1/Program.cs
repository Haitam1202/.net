﻿using System;

class So
{
    public double GiaTri { get; set; }

    public So(double giaTri)
    {
        GiaTri = giaTri;
    }

    public double Cong(So s) => this.GiaTri + s.GiaTri;
    public double Tru(So s) => this.GiaTri - s.GiaTri;
    public double Nhan(So s) => this.GiaTri * s.GiaTri;
    public double Chia(So s) => s.GiaTri != 0 ? this.GiaTri / s.GiaTri : double.NaN;
}

// Sử dụng:
class Program
{
    static void Main()
    {
        So a = new So(10);
        So b = new So(5);

        Console.WriteLine("Tổng: " + a.Cong(b));
        Console.WriteLine("Hiệu: " + a.Tru(b));
        Console.WriteLine("Tích: " + a.Nhan(b));
        Console.WriteLine("Thương: " + a.Chia(b));
        Console.ReadLine();
    }
}
