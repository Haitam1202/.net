﻿using QLBanHang.BUS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBanHang.GUI
{
    public partial class FormHang : Form
    {
        public FormHang()
        {
            InitializeComponent();
        }
        HangBUS bus = new HangBUS(); // tạo đối tượng BUS
        private void btnThem_Click(object sender, EventArgs e)
        {
            // Gọi BUS để thêm dữ liệu từ các textbox
            bus.ThemHang(txtMaHang.Text, txtTenHang.Text, float.Parse(txtDonGia.Text), txtGhiChu.Text);
            MessageBox.Show("Thêm thành công!");

            // Tải lại dữ liệu sau khi thêm
            dgvHang.DataSource = bus.LayDanhSachHang();
        }

        private void btnXem_Click(object sender, EventArgs e)
        {
            // Hiển thị danh sách hàng
            dgvHang.DataSource = bus.LayDanhSachHang();
        }
    }
}
