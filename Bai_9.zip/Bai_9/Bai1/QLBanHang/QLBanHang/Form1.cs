﻿using QLBanHang.GUI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace QLBanHang
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void quảnLýHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHang f = new FormHang();
            f.ShowDialog(); // mở form quản lý hàng
        }

        private void quảnLýKháchHàngToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormKhachHang f = new FormKhachHang();
            f.ShowDialog(); // mở form quản lý khách hàng
        }

        private void quảnLýHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHoaDon f = new FormHoaDon();
            f.ShowDialog(); // mở form quản lý hóa đơn
        }

        private void chiTiếtHóaĐơnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHDCT f = new FormHDCT();
            f.ShowDialog(); // mở form quản lý chi tiết hóa đơn
        }

        private void quảnLýChiTiếtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormHDCT f = new FormHDCT();
            f.ShowDialog();
        }


    }
}
