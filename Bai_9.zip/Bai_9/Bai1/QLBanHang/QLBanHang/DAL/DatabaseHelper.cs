﻿using System.Data.SqlClient;

public class DatabaseHelper
{
    public static SqlConnection GetConnection()
    {
        return new SqlConnection("Data Source=localhost\\MSSQLSERVER02;Initial Catalog=QuanLyBanHang;Integrated Security=True");
    }
}
