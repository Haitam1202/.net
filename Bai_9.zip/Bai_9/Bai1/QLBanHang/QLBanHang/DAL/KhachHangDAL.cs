﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.DAL
{
    public class KhachHangDAL
    {
        public DataTable GetAll()
        {
            SqlConnection conn = DatabaseHelper.GetConnection();
            SqlDataAdapter da = new SqlDataAdapter("sp_GetAllKhachHang", conn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            da.Fill(dt);
            return dt;
        }

        public void Them(string ma, string ten, string sdt, string ghichu)
        {
            SqlConnection conn = DatabaseHelper.GetConnection();
            try
            {
                SqlCommand cmd = new SqlCommand("sp_ThemKhachHang", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaKH", ma);
                cmd.Parameters.AddWithValue("@TenKH", ten);
                cmd.Parameters.AddWithValue("@SDT", sdt);
                cmd.Parameters.AddWithValue("@GhiChu", ghichu);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            finally
            {
                conn.Close();
            }

        }
    }

}
