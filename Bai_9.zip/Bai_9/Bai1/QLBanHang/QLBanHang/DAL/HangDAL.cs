﻿using System.Data;
using System.Data.SqlClient;

public class HangDAL
{
    public DataTable GetAll()
    {
        SqlConnection conn = DatabaseHelper.GetConnection();
        SqlDataAdapter da = new SqlDataAdapter("sp_GetAllHang", conn);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }

    public void Them(string ma, string ten, float gia, string ghichu)
    {
        SqlConnection conn = DatabaseHelper.GetConnection();
        try
        {
            SqlCommand cmd = new SqlCommand("sp_ThemHang", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@MaHang", ma);
            cmd.Parameters.AddWithValue("@TenHang", ten);
            cmd.Parameters.AddWithValue("@DonGia", gia);
            cmd.Parameters.AddWithValue("@GhiChu", ghichu);
            conn.Open();
            cmd.ExecuteNonQuery();
        }
        finally
        {
            conn.Close();
        }

    }
}
