﻿using QLBanHang.DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.BUS
{
    public class KhachHangBUS
    {
        KhachHangDAL dal = new KhachHangDAL();

        public DataTable LayDanhSachKhachHang() => dal.GetAll();
        public void ThemKhachHang(string ma, string ten, string sdt, string ghichu) => dal.Them(ma, ten, sdt, ghichu);
    }

}
