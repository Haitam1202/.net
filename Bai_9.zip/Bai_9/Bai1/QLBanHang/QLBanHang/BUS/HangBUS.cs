﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLBanHang.BUS
{
    public class HangBUS
    {
        HangDAL dal = new HangDAL();

        public DataTable LayDanhSachHang() => dal.GetAll();
        public void ThemHang(string ma, string ten, float gia, string ghichu) => dal.Them(ma, ten, gia, ghichu);
    }

}
