﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        Console.WriteLine("----- MENU HÌNH VẼ -----");
        Console.WriteLine("1. Tam giác vuông đặc");
        Console.WriteLine("2. Tam giác vuông rỗng");
        Console.WriteLine("3. Hình vuông rỗng");
        Console.Write("Nhập lựa chọn (1-3): ");
        int luaChon = int.Parse(Console.ReadLine());

        Console.Write("Nhập chiều cao (hoặc cạnh): ");
        int h = int.Parse(Console.ReadLine());

        Console.WriteLine("\n--- KẾT QUẢ ---");

        switch (luaChon)
        {
            case 1: // Tam giác vuông đặc
                for (int i = 1; i <= h; i++)
                {
                    for (int j = 1; j <= i; j++)
                        Console.Write("*");
                    Console.WriteLine();
                }
                break;

            case 2: // Tam giác vuông rỗng
                for (int i = 1; i <= h; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        if (j == 1 || j == i || i == h)
                            Console.Write("*");
                        else
                            Console.Write(" ");
                    }
                    Console.WriteLine();
                }
                break;

            case 3: // Hình vuông rỗng
                for (int i = 1; i <= h; i++)
                {
                    for (int j = 1; j <= h; j++)
                    {
                        if (i == 1 || i == h || j == 1 || j == h)
                            Console.Write("*");
                        else
                            Console.Write(" ");
                    }
                    Console.WriteLine();
                }
                break;

            default:
                Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn từ 1 đến 3.");
                break;
        }
    }
}
