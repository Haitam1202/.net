﻿using System;

class Program
{
    static void Main()
    {
        int n;
        bool isPrime = true;

        Console.Write("Nhập một số nguyên n: ");
        n = int.Parse(Console.ReadLine());

        if (n < 2)
        {
            isPrime = false; // Số < 2 không phải là số nguyên tố
        }
        else
        {
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0)
                {
                    isPrime = false;
                    break;
                }
            }
        }

        if (isPrime)
        {
            Console.WriteLine("{0} là số nguyên tố.", n);
        }
        else
        {
            Console.WriteLine("{0} không phải là số nguyên tố.", n);
        }

        Console.ReadLine(); // Giữ màn hình console
    }
}
