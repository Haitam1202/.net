﻿using System;

class Program
{
    enum ChuSo
    {
        Không, Một, Hai, Ba, Bốn, Năm, Sáu, Bảy, Tám, Chín
    }

    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.Write("Nhập số (từ 10 đến 99): ");
        int number = int.Parse(Console.ReadLine());

        if (number < 10 || number > 99)
        {
            Console.WriteLine("Vui lòng nhập số từ 10 đến 99.");
            return;
        }

        int chuc = number / 10;
        int donvi = number % 10;

        switch (chuc)
        {
            case 1: Console.Write("Mười "); break;
            case 2: Console.Write("Hai mươi "); break;
            case 3: Console.Write("Ba mươi "); break;
            case 4: Console.Write("Bốn mươi "); break;
            case 5: Console.Write("Năm mươi "); break;
            case 6: Console.Write("Sáu mươi "); break;
            case 7: Console.Write("Bảy mươi "); break;
            case 8: Console.Write("Tám mươi "); break;
            case 9: Console.Write("Chín mươi "); break;
        }

        if (donvi > 0 || chuc == 1)
        {
            switch (donvi)
            {
                case 1: Console.WriteLine("mốt"); break;
                case 5: Console.WriteLine("lăm"); break;
                default:
                    Console.WriteLine(((ChuSo)donvi).ToString().ToLower());
                    break;
            }
        }
        else Console.WriteLine(); // số tròn chục
    }
}
