﻿using System;

namespace BaiTapConsole
{
    class Nguoi
    {
        // Các thuộc tính
        public string HoTen { get; set; }
        public string CMND { get; set; }
        public string QueQuan { get; set; }
        public string GhiChu { get; set; }

        // Constructor không đối số
        public Nguoi() { }

        // Constructor có đối số
        public Nguoi(string hoTen, string cmnd, string queQuan, string ghiChu)
        {
            HoTen = hoTen;
            CMND = cmnd;
            QueQuan = queQuan;
            GhiChu = ghiChu;
        }

        // Nạp chồng phương thức ToString để hiển thị thông tin người
        public override string ToString()
        {
            return $"Họ tên: {HoTen}\nCMND: {CMND}\nQuê quán: {QueQuan}\nGhi chú: {GhiChu}";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Tạo đối tượng người và nhập dữ liệu từ bàn phím
            Console.Write("Nhập họ tên: ");
            string hoTen = Console.ReadLine();

            Console.Write("Nhập CMND: ");
            string cmnd = Console.ReadLine();

            Console.Write("Nhập quê quán: ");
            string queQuan = Console.ReadLine();

            Console.Write("Nhập ghi chú: ");
            string ghiChu = Console.ReadLine();

            // Khởi tạo đối tượng
            Nguoi nguoi = new Nguoi(hoTen, cmnd, queQuan, ghiChu);

            // Hiển thị thông tin
            Console.WriteLine("\nThông tin người:");
            Console.WriteLine(nguoi.ToString());

            Console.ReadLine(); // Dừng màn hình
        }
    }
}
