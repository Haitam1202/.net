﻿using System;

class Program
{
    static void Main()
    {
        int n;
        double sum = 0;

        Console.Write("Nhập số nguyên dương n: ");
        n = int.Parse(Console.ReadLine());

        if (n <= 0)
        {
            Console.WriteLine("Vui lòng nhập số nguyên dương lớn hơn 0.");
        }
        else
        {
            for (int i = 1; i <= n; i++)
            {
                sum += 1.0 / i; // Cần ép kiểu để chia ra số thực
            }

            Console.WriteLine("Tổng S = 1 + 1/2 + ... + 1/{0} là: {1}", n, sum);
        }

        Console.ReadLine(); // Giữ cửa sổ console
    }
}
