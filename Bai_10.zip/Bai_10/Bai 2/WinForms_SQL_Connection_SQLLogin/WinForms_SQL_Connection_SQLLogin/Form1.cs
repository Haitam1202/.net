﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_SQL_Connection_SQLLogin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            DBConnection db = new DBConnection()
            {
                Server = @"localhost\MSSQLSERVER02",  
                Database = "TestDB",
                Username = "sqluser",                 
                Password = "123456"
            };

            try
            {
                using (SqlConnection conn = db.GetConnection())
                {
                    conn.Open();
                    MessageBox.Show("Kết nối thành công!", "Thông báo");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi kết nối: " + ex.Message, "Lỗi");
            }
        }

    }
}
