﻿using System.Data.SqlClient;

namespace WinForms_SQL_Connection_SQLLogin
{
    public class DBConnection
    {
        public string Server { get; set; }
        public string Database { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public SqlConnection GetConnection()
        {
            string connStr = $"Data Source={Server};Initial Catalog={Database};User ID={Username};Password={Password}";
            return new SqlConnection(connStr);
        }
    }
}
