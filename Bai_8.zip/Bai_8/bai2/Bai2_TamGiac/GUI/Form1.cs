﻿using BUS;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            try
            {
                // Lấy dữ liệu từ giao diện
                TamGiacDAL tg = new TamGiacDAL
                {
                    A = double.Parse(txtA.Text),
                    B = double.Parse(txtB.Text),
                    C = double.Parse(txtC.Text)
                };

                // Gọi lớp xử lý nghiệp vụ
                TamGiacBUS bus = new TamGiacBUS();

                // Kiểm tra tam giác
                if (!bus.LaTamGiac(tg))
                {
                    lblKQ.Text = "Không phải là tam giác.";
                }
                else
                {
                    string loai = bus.LoaiTamGiac(tg);
                    double chuVi = bus.TinhChuVi(tg);
                    double dienTich = bus.TinhDienTich(tg);

                    lblKQ.Text = $"Loại: {loai}\nChu vi: {chuVi:F2}\nDiện tích: {dienTich:F2}";
                }
            }
            catch
            {
                MessageBox.Show("Vui lòng nhập đúng 3 số thực!");
            }
        }

    }
}
