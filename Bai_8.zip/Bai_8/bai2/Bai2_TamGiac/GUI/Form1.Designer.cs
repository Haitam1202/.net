﻿namespace GUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblA = new System.Windows.Forms.Label();
            this.txtA = new System.Windows.Forms.TextBox();
            this.lblB = new System.Windows.Forms.Label();
            this.txtB = new System.Windows.Forms.TextBox();
            this.lblC = new System.Windows.Forms.Label();
            this.txtC = new System.Windows.Forms.TextBox();
            this.btnKiemTra = new System.Windows.Forms.Button();
            this.lblKQ = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(68, 73);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(86, 16);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "Nhập Cạnh A";
            // 
            // txtA
            // 
            this.txtA.Location = new System.Drawing.Point(53, 107);
            this.txtA.Name = "txtA";
            this.txtA.Size = new System.Drawing.Size(118, 22);
            this.txtA.TabIndex = 1;
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(255, 73);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(86, 16);
            this.lblB.TabIndex = 2;
            this.lblB.Text = "Nhập Cạnh B";
            // 
            // txtB
            // 
            this.txtB.Location = new System.Drawing.Point(243, 107);
            this.txtB.Name = "txtB";
            this.txtB.Size = new System.Drawing.Size(115, 22);
            this.txtB.TabIndex = 3;
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(501, 73);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(86, 16);
            this.lblC.TabIndex = 4;
            this.lblC.Text = "Nhập Cạnh C";
            // 
            // txtC
            // 
            this.txtC.Location = new System.Drawing.Point(475, 107);
            this.txtC.Name = "txtC";
            this.txtC.Size = new System.Drawing.Size(143, 22);
            this.txtC.TabIndex = 5;
            // 
            // btnKiemTra
            // 
            this.btnKiemTra.Location = new System.Drawing.Point(149, 204);
            this.btnKiemTra.Name = "btnKiemTra";
            this.btnKiemTra.Size = new System.Drawing.Size(94, 35);
            this.btnKiemTra.TabIndex = 6;
            this.btnKiemTra.Text = "Kiểm Tra";
            this.btnKiemTra.UseVisualStyleBackColor = true;
            this.btnKiemTra.Click += new System.EventHandler(this.btnKiemTra_Click);
            // 
            // lblKQ
            // 
            this.lblKQ.AutoSize = true;
            this.lblKQ.Location = new System.Drawing.Point(314, 211);
            this.lblKQ.Name = "lblKQ";
            this.lblKQ.Size = new System.Drawing.Size(0, 16);
            this.lblKQ.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblKQ);
            this.Controls.Add(this.btnKiemTra);
            this.Controls.Add(this.txtC);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.txtB);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.txtA);
            this.Controls.Add(this.lblA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.TextBox txtA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.TextBox txtB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtC;
        private System.Windows.Forms.Button btnKiemTra;
        private System.Windows.Forms.Label lblKQ;
    }
}