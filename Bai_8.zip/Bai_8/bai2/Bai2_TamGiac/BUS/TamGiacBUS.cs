﻿using System;
using DAL;

namespace BUS
{
    public class TamGiacBUS
    {
        public bool LaTamGiac(TamGiacDAL tg)
        {
            return tg.A + tg.B > tg.C &&
                   tg.A + tg.C > tg.B &&
                   tg.B + tg.C > tg.A;
        }

        public string LoaiTamGiac(TamGiacDAL tg)
        {
            if (tg.A == tg.B && tg.B == tg.C)
                return "Tam giác đều";
            else if (tg.A == tg.B || tg.B == tg.C || tg.A == tg.C)
                return "Tam giác cân";
            else if (Math.Abs(tg.A * tg.A + tg.B * tg.B - tg.C * tg.C) < 0.001 ||
                     Math.Abs(tg.B * tg.B + tg.C * tg.C - tg.A * tg.A) < 0.001 ||
                     Math.Abs(tg.A * tg.A + tg.C * tg.C - tg.B * tg.B) < 0.001)
                return "Tam giác vuông";
            else
                return "Tam giác thường";
        }

        public double TinhChuVi(TamGiacDAL tg)
        {
            return tg.A + tg.B + tg.C;
        }

        public double TinhDienTich(TamGiacDAL tg)
        {
            double p = TinhChuVi(tg) / 2;
            return Math.Sqrt(p * (p - tg.A) * (p - tg.B) * (p - tg.C));
        }
    }
}
