﻿using DAL;

namespace BUS
{
    public class TinhTongBUS
    {
        public int TinhTong(NumberDAL number)
        {
            return number.SoA + number.SoB;
        }
    }
}
