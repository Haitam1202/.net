﻿using BUS;
using DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnTinh_Click(object sender, EventArgs e)
        {
            try
            {
                NumberDAL number = new NumberDAL
                {
                    SoA = int.Parse(txtA.Text),
                    SoB = int.Parse(txtB.Text)
                };

                TinhTongBUS bus = new TinhTongBUS();
                int ketQua = bus.TinhTong(number);

                lblKetQua.Text = "Kết quả: " + ketQua.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập dữ liệu: " + ex.Message);
            }
        }
    }
}
