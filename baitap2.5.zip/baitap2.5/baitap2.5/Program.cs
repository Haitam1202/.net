﻿using System;

class Program
{
    static void Main()
    {
        int n;

        Console.Write("Nhập số lượng số Fibonacci cần hiển thị (n >= 1): ");
        n = int.Parse(Console.ReadLine());

        if (n <= 0)
        {
            Console.WriteLine("Vui lòng nhập số nguyên dương lớn hơn 0.");
        }
        else
        {
            Console.WriteLine("Dãy Fibonacci gồm {0} số đầu tiên:", n);

            int a = 0, b = 1;

            for (int i = 1; i <= n; i++)
            {
                Console.Write(a + " ");

                int next = a + b;
                a = b;
                b = next;
            }
        }

        Console.ReadLine(); // Giữ cửa sổ console
    }
}
