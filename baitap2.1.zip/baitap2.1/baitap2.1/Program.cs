﻿using System;

class Program
{
    static void Main()
    {
        int n;
        int sum = 0;

        Console.Write("Nhập số nguyên dương n: ");
        n = int.Parse(Console.ReadLine());

        if (n <= 0)
        {
            Console.WriteLine("Vui lòng nhập số nguyên dương lớn hơn 0.");
        }
        else
        {
            for (int i = 2; i <= n; i += 2)
            {
                sum += i;
            }

            Console.WriteLine("Tổng các số chẵn từ 2 đến {0} là: {1}", n, sum);
        }

        Console.ReadLine(); // Giữ cửa sổ console mở
    }
}
