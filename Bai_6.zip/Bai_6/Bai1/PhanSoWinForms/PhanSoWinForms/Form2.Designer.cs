﻿namespace PhanSoWinForms
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblTong = new System.Windows.Forms.Label();
            this.lblHieu = new System.Windows.Forms.Label();
            this.lblTich = new System.Windows.Forms.Label();
            this.lblThuong = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblTong
            // 
            this.lblTong.AutoSize = true;
            this.lblTong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTong.Location = new System.Drawing.Point(135, 98);
            this.lblTong.Name = "lblTong";
            this.lblTong.Size = new System.Drawing.Size(46, 20);
            this.lblTong.TabIndex = 0;
            this.lblTong.Text = "Tổng";
            this.lblTong.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblHieu
            // 
            this.lblHieu.AutoSize = true;
            this.lblHieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHieu.Location = new System.Drawing.Point(279, 98);
            this.lblHieu.Name = "lblHieu";
            this.lblHieu.Size = new System.Drawing.Size(44, 20);
            this.lblHieu.TabIndex = 1;
            this.lblHieu.Text = "Hiệu";
            this.lblHieu.Click += new System.EventHandler(this.lblHieu_Click);
            // 
            // lblTich
            // 
            this.lblTich.AutoSize = true;
            this.lblTich.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTich.Location = new System.Drawing.Point(135, 170);
            this.lblTich.Name = "lblTich";
            this.lblTich.Size = new System.Drawing.Size(41, 20);
            this.lblTich.TabIndex = 2;
            this.lblTich.Text = "Tích";
            // 
            // lblThuong
            // 
            this.lblThuong.AutoSize = true;
            this.lblThuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThuong.Location = new System.Drawing.Point(279, 170);
            this.lblThuong.Name = "lblThuong";
            this.lblThuong.Size = new System.Drawing.Size(64, 20);
            this.lblThuong.TabIndex = 3;
            this.lblThuong.Text = "Thương";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(592, 328);
            this.Controls.Add(this.lblThuong);
            this.Controls.Add(this.lblTich);
            this.Controls.Add(this.lblHieu);
            this.Controls.Add(this.lblTong);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTong;
        private System.Windows.Forms.Label lblHieu;
        private System.Windows.Forms.Label lblTich;
        private System.Windows.Forms.Label lblThuong;
    }
}