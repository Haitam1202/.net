﻿using System;

namespace PhanSoWinForms
{
    public class PhanSo
    {
        public int Tu { get; set; }
        public int Mau { get; set; }

        public PhanSo(int tu = 0, int mau = 1)
        {
            if (mau == 0) throw new ArgumentException("Mẫu số không được bằng 0");
            Tu = tu;
            Mau = mau;
            RutGon();
        }

        private void RutGon()
        {
            int ucln = UCLN(Math.Abs(Tu), Math.Abs(Mau));
            Tu /= ucln;
            Mau /= ucln;
            if (Mau < 0) { Tu = -Tu; Mau = -Mau; }
        }

        private int UCLN(int a, int b)
        {
            while (b != 0)
            {
                int temp = a % b;
                a = b;
                b = temp;
            }
            return a;
        }

        public static PhanSo operator +(PhanSo a, PhanSo b)
            => new PhanSo(a.Tu * b.Mau + b.Tu * a.Mau, a.Mau * b.Mau);

        public static PhanSo operator -(PhanSo a, PhanSo b)
            => new PhanSo(a.Tu * b.Mau - b.Tu * a.Mau, a.Mau * b.Mau);

        public static PhanSo operator *(PhanSo a, PhanSo b)
            => new PhanSo(a.Tu * b.Tu, a.Mau * b.Mau);

        public static PhanSo operator /(PhanSo a, PhanSo b)
        {
            if (b.Tu == 0) throw new DivideByZeroException("Không chia được cho 0");
            return new PhanSo(a.Tu * b.Mau, a.Mau * b.Tu);
        }

        public override string ToString() => $"{Tu}/{Mau}";
    }
}
