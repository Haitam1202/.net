﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PhanSoWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnTinh_Click(object sender, EventArgs e)
        {
            try
            {
                int tu1 = int.Parse(txtTu1.Text);
                int mau1 = int.Parse(txtMau1.Text);
                int tu2 = int.Parse(txtTu2.Text);
                int mau2 = int.Parse(txtMau2.Text);

                PhanSo ps1 = new PhanSo(tu1, mau1);
                PhanSo ps2 = new PhanSo(tu2, mau2);

                Form2 frm = new Form2(ps1, ps2);
                frm.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

    }
}
