﻿namespace PhanSoWinForms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtTu1 = new System.Windows.Forms.TextBox();
            this.txtMau1 = new System.Windows.Forms.TextBox();
            this.txtTu2 = new System.Windows.Forms.TextBox();
            this.txtMau2 = new System.Windows.Forms.TextBox();
            this.btnTinh = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtTu1
            // 
            this.txtTu1.Location = new System.Drawing.Point(98, 63);
            this.txtTu1.Name = "txtTu1";
            this.txtTu1.Size = new System.Drawing.Size(100, 22);
            this.txtTu1.TabIndex = 0;
            // 
            // txtMau1
            // 
            this.txtMau1.Location = new System.Drawing.Point(98, 122);
            this.txtMau1.Name = "txtMau1";
            this.txtMau1.Size = new System.Drawing.Size(100, 22);
            this.txtMau1.TabIndex = 1;
            // 
            // txtTu2
            // 
            this.txtTu2.Location = new System.Drawing.Point(275, 63);
            this.txtTu2.Name = "txtTu2";
            this.txtTu2.Size = new System.Drawing.Size(100, 22);
            this.txtTu2.TabIndex = 2;
            // 
            // txtMau2
            // 
            this.txtMau2.Location = new System.Drawing.Point(275, 122);
            this.txtMau2.Name = "txtMau2";
            this.txtMau2.Size = new System.Drawing.Size(100, 22);
            this.txtMau2.TabIndex = 3;
            // 
            // btnTinh
            // 
            this.btnTinh.Location = new System.Drawing.Point(180, 190);
            this.btnTinh.Name = "btnTinh";
            this.btnTinh.Size = new System.Drawing.Size(107, 55);
            this.btnTinh.TabIndex = 4;
            this.btnTinh.Text = "Tính Toán";
            this.btnTinh.UseVisualStyleBackColor = true;
            this.btnTinh.Click += new System.EventHandler(this.btnTinh_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(460, 343);
            this.Controls.Add(this.btnTinh);
            this.Controls.Add(this.txtMau2);
            this.Controls.Add(this.txtTu2);
            this.Controls.Add(this.txtMau1);
            this.Controls.Add(this.txtTu1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtTu1;
        private System.Windows.Forms.TextBox txtMau1;
        private System.Windows.Forms.TextBox txtTu2;
        private System.Windows.Forms.TextBox txtMau2;
        private System.Windows.Forms.Button btnTinh;
    }
}

