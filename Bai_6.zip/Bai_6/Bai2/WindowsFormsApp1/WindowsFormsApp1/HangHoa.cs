﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public class HangHoa
    {
        public string MaHang { get; set; }
        public string TenHang { get; set; }
        public double DonGia { get; set; }

        public HangHoa(string ma, string ten, double gia)
        {
            MaHang = ma;
            TenHang = ten;
            DonGia = gia;
        }

        public override string ToString()
        {
            return $"Mã hàng: {MaHang}\\nTên hàng: {TenHang}\\nĐơn giá: {DonGia:N0} VNĐ";
        }
    }
}
