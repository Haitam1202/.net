﻿class Nguoi
{
    public string HoTen { get; set; }
    public string CMND { get; set; }
    public string QueQuan { get; set; }
    public string GhiChu { get; set; }

    public Nguoi() { }

    public Nguoi(string hoTen, string cmnd, string queQuan, string ghiChu)
    {
        HoTen = hoTen;
        CMND = cmnd;
        QueQuan = queQuan;
        GhiChu = ghiChu;
    }

    public override string ToString()
    {
        return $"Họ tên: {HoTen}\nCMND: {CMND}\nQuê quán: {QueQuan}\nGhi chú: {GhiChu}";
    }
}
class SV1 : Nguoi
{
    public string MaSV { get; set; }

    public SV1(string hoTen, string cmnd, string queQuan, string ghiChu, string maSV)
        : base(hoTen, cmnd, queQuan, ghiChu)
    {
        MaSV = maSV;
    }

    public void HienThi()
    {
        Console.WriteLine("=== Sinh viên SV1 (Kế thừa) ===");
        Console.WriteLine($"Mã SV: {MaSV}");
        Console.WriteLine(base.ToString());
    }
}
class SV2
{
    public string MaSV { get; set; }
    public Nguoi CaNhan { get; set; }

    public SV2(string maSV, Nguoi caNhan)
    {
        MaSV = maSV;
        CaNhan = caNhan;
    }

    public void HienThi()
    {
        Console.WriteLine("=== Sinh viên SV2 (Kết tập) ===");
        Console.WriteLine($"Mã SV: {MaSV}");
        Console.WriteLine(CaNhan.ToString());
    }
}
class Program
{
    static void Main(string[] args)
    {
        // Khởi tạo SV1 (kế thừa)
        SV1 sv1 = new SV1("Nguyễn Văn An", "123456", "Hà Nội", "totnghiep", "SV001");
        sv1.HienThi();

        Console.WriteLine();

        // Khởi tạo SV2 (kết tập)
        Nguoi nguoiB = new Nguoi("Trần Thị Bê", "987654", "TP.HCM", "totnghiep");
        SV2 sv2 = new SV2("SV002", nguoiB);
        sv2.HienThi();

        Console.ReadLine();
    }
}
