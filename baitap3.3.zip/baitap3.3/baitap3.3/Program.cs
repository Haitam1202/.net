﻿using System;

class SV
{
    // Thuộc tính của sinh viên
    public string MaSV { get; set; }
    public string HoTen { get; set; }
    public string Lop { get; set; }
    public DateTime NgaySinh { get; set; }
    public string GioiTinh { get; set; }
    public double DiemTB { get; set; }

    // Constructor
    public SV(string maSV, string hoTen, string lop, DateTime ngaySinh, string gioiTinh, double diemTB)
    {
        MaSV = maSV;
        HoTen = hoTen;
        Lop = lop;
        NgaySinh = ngaySinh;
        GioiTinh = gioiTinh;
        DiemTB = diemTB;
    }

    // Phương thức hiển thị dạng bảng
    public void HienThi()
    {
        Console.WriteLine("+--------+----------------------+--------+------------+-----------+--------+");
        Console.WriteLine("| Mã SV  | Họ tên               | Lớp    | Ngày sinh  | Giới tính| Điểm TB|");
        Console.WriteLine("+--------+----------------------+--------+------------+-----------+--------+");
        Console.WriteLine($"| {MaSV,-6} | {HoTen,-20} | {Lop,-6} | {NgaySinh:dd/MM/yyyy} | {GioiTinh,-9} | {DiemTB,6:F2} |");
        Console.WriteLine("+--------+----------------------+--------+------------+-----------+--------+");
    }
}
class Program
{
    static void Main()
    {
        // Nhập thông tin sinh viên từ bàn phím
        Console.Write("Nhập mã SV: ");
        string ma = Console.ReadLine();

        Console.Write("Nhập họ tên: ");
        string ten = Console.ReadLine();

        Console.Write("Nhập lớp: ");
        string lop = Console.ReadLine();

        Console.Write("Nhập ngày sinh (dd/MM/yyyy): ");
        DateTime ngaySinh = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy", null);

        Console.Write("Nhập giới tính: ");
        string gioiTinh = Console.ReadLine();

        Console.Write("Nhập điểm trung bình: ");
        double diem = double.Parse(Console.ReadLine());

        // Tạo đối tượng sinh viên
        SV sv = new SV(ma, ten, lop, ngaySinh, gioiTinh, diem);

        Console.WriteLine("\nThông tin sinh viên:");
        sv.HienThi();

        Console.ReadLine();
    }
}
