﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace ReportDemo
{
    public partial class FormBaoCaoHang : Form
    {
        public FormBaoCaoHang()
        {
            InitializeComponent();
        }

        private void FormBaoCaoHang_Load(object sender, EventArgs e)
        {
            ReportDocument rpt = new ReportDocument();
            string path = Application.StartupPath + @"\rptDanhSachHang.rpt";
            rpt.Load(path);

            // Thiết lập kết nối
            ConnectionInfo connInfo = new ConnectionInfo();
            connInfo.ServerName = @"localhost\MSSQLSERVER02";
            connInfo.DatabaseName = "QLHangHoa";
            connInfo.IntegratedSecurity = true;

            foreach (Table table in rpt.Database.Tables)
            {
                TableLogOnInfo logonInfo = table.LogOnInfo;
                logonInfo.ConnectionInfo = connInfo;
                table.ApplyLogOnInfo(logonInfo);
            }

            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();
        }
    }
}

