﻿using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ReportThang03
{
    public partial class ReportThang03 : Form
    {
        public ReportThang03()
        {
            InitializeComponent();
        }

        private void ReportThang03_Load(object sender, EventArgs e)
        {
            // Tạo báo cáo
            ReportDocument rpt = new ReportDocument();
            rpt.Load(@"rptHangBanThang3.rpt");

            // Gán dữ liệu kết nối trực tiếp cho báo cáo
            rpt.SetDatabaseLogon("sa", "123", @"localhost", "QLBanHang"); // sửa theo tài khoản SQL của bạn

            // Gán báo cáo vào CrystalReportViewer
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();
        }

    }
}

