﻿using System;
using System.Windows.Forms;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace ReportDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {
            // Tạo đối tượng báo cáo
            ReportDocument rpt = new ReportDocument();

            // Load đường dẫn tuyệt đối đến file .rpt
            string path = Application.StartupPath + @"\rptKhachHangDaMua.rpt";
            rpt.Load(path);


            // Kết nối Windows Authentication
            ConnectionInfo connInfo = new ConnectionInfo();
            connInfo.ServerName = @"localhost\MSSQLSERVER02";
            connInfo.DatabaseName = "KhachHangDB";
            connInfo.IntegratedSecurity = true;

            // Gán thông tin kết nối cho tất cả bảng
            Tables tables = rpt.Database.Tables;
            foreach (Table table in tables)
            {
                TableLogOnInfo logonInfo = table.LogOnInfo;
                logonInfo.ConnectionInfo = connInfo;
                table.ApplyLogOnInfo(logonInfo);
            }

            // Gán báo cáo cho CrystalReportViewer
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();
        }
    }
}
