﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("Rằm Tháng Giêng");
        Console.WriteLine("Rằm xuân lồng lộng trăng soi,");
        Console.WriteLine("Sông xuân nước lẫn màu trời thêm xuân.");
        Console.WriteLine("Giữa dòng bàn bạc việc quân");
        Console.WriteLine("Khuya về bát ngát trăng ngân đầy thuyền.");
        Console.WriteLine("Hồ Chí Minh.");
    }
}
