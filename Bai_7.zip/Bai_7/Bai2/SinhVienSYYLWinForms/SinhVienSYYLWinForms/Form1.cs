﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;



namespace SinhVienSYYLWinForms
{

    public partial class Form1 : Form
    {
        private List<SinhVien> danhSach = new List<SinhVien>();

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void btnChonHinh_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtHinh.Text = openFileDialog1.FileName;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string ma = txtMaSV.Text.Trim();
            string ten = txtHoTen.Text.Trim();
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            DateTime ngaySinh = dtpNgaySinh.Value;
            string que = txtQue.Text.Trim();
            string hinh = txtHinh.Text.Trim();

            SinhVien sv = new SinhVien(ma, ten, gioiTinh, ngaySinh, que, hinh);
            danhSach.Add(sv);

            dgvDanhSach.DataSource = null; // reset để cập nhật lại
            dgvDanhSach.DataSource = danhSach;
        }

        private void radNamm_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
