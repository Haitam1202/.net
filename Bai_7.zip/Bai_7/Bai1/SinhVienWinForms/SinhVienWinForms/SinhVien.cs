﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SinhVienWinForms
{
    public class SinhVien
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public string Anh { get; set; }

        public SinhVien(string ma, string ten, string anh)
        {
            MaSV = ma;
            HoTen = ten;
            Anh = anh;
        }
    }

}
