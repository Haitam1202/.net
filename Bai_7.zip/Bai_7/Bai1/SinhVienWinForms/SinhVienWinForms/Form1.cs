﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SinhVienWinForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtAnh.Text = openFileDialog1.FileName;
                picAnh.ImageLocation = openFileDialog1.FileName;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string ma = txtMaSV.Text.Trim();
            string ten = txtHoTen.Text.Trim();
            string anh = txtAnh.Text.Trim();

            if (string.IsNullOrEmpty(ma) || string.IsNullOrEmpty(ten) || string.IsNullOrEmpty(anh))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!");
                return;
            }

            SinhVien sv = new SinhVien(ma, ten, anh);

            ListViewItem item = new ListViewItem(sv.MaSV);
            item.SubItems.Add(sv.HoTen);
            item.SubItems.Add(sv.Anh);
            lvSinhVien.Items.Add(item);

            picAnh.ImageLocation = sv.Anh;

            txtMaSV.Clear();
            txtHoTen.Clear();
            txtAnh.Clear();
        }   

        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count > 0)
            {
                string duongDanAnh = lvSinhVien.SelectedItems[0].SubItems[2].Text;
                picAnh.ImageLocation = duongDanAnh;
            }
        }

        private void picAnh_Click(object sender, EventArgs e)
        {

        }
    }
}
