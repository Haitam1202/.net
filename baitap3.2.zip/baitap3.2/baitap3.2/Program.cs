﻿using System;

class TamGiac
{
    public double A, B, C;

    public TamGiac(double a, double b, double c)
    {
        A = a; B = b; C = c;
    }

    public bool LaTamGiac()
    {
        return A + B > C && A + C > B && B + C > A;
    }

    public double ChuVi()
    {
        return A + B + C;
    }

    public double DienTich()
    {
        double p = ChuVi() / 2;
        return Math.Sqrt(p * (p - A) * (p - B) * (p - C)); // Heron
    }
}

// Sử dụng:
class Program
{
    static void Main()
    {
        Console.Write("Nhập cạnh a: ");
        double a = double.Parse(Console.ReadLine());

        Console.Write("Nhập cạnh b: ");
        double b = double.Parse(Console.ReadLine());

        Console.Write("Nhập cạnh c: ");
        double c = double.Parse(Console.ReadLine());

        TamGiac tg = new TamGiac(a, b, c);

        if (tg.LaTamGiac())
        {
            Console.WriteLine("\n✔ Là tam giác.");
            Console.WriteLine("Chu vi = " + tg.ChuVi());
            Console.WriteLine("Diện tích = " + tg.DienTich());
        }
        else
        {
            Console.WriteLine("\n✘ Không phải là tam giác.");
        }

        Console.ReadLine(); // Đợi người dùng nhấn Enter
    }
}
