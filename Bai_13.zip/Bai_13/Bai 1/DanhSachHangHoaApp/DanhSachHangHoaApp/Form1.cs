﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanhSachHangHoaApp
{
    public partial class Form1 : Form
    {
        // Danh sách hàng hóa kiểu Generic
        private List<HangHoa> danhSachHangHoa = new List<HangHoa>();

        public Form1()
        {
            InitializeComponent();
        }

        // Sự kiện click nút Nạp Dữ Liệu
        private void btnNapDuLieu_Click(object sender, EventArgs e)
        {
            // Xóa dữ liệu cũ nếu có
            danhSachHangHoa.Clear();

            // Thêm dữ liệu mẫu
            danhSachHangHoa.Add(new HangHoa { MaHang = "HH01", TenHang = "Bàn phím", SoLuong = 10, DonGia = 250000 });
            danhSachHangHoa.Add(new HangHoa { MaHang = "HH02", TenHang = "Chuột", SoLuong = 15, DonGia = 150000 });
            danhSachHangHoa.Add(new HangHoa { MaHang = "HH03", TenHang = "Tai nghe", SoLuong = 7, DonGia = 300000 });

            // Hiển thị ra ListBox
            HienThiHangHoa();
        }

        // Hàm hiển thị lên ListBox
        private void HienThiHangHoa()
        {
            lstHangHoa.Items.Clear();
            foreach (var hh in danhSachHangHoa)
            {
                lstHangHoa.Items.Add(hh.ToString());
            }
        }
    }
}
