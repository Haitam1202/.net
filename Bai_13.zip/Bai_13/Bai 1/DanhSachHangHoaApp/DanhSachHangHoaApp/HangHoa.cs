﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanhSachHangHoaApp
{
    public class HangHoa
    {
        public string MaHang { get; set; }
        public string TenHang { get; set; }
        public int SoLuong { get; set; }
        public double DonGia { get; set; }

        public override string ToString()
        {
            return $"Mã: {MaHang} | Tên: {TenHang} | SL: {SoLuong} | Giá: {DonGia:N0}đ";
        }
    }

}
