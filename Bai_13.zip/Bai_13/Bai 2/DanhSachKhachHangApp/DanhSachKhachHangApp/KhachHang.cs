﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanhSachKhachHangApp
{
    public class KhachHang
    {
        public string MaKH { get; set; }
        public string HoTen { get; set; }
        public string DienThoai { get; set; }
        public string DiaChi { get; set; }

        public override string ToString()
        {
            return $"Mã KH: {MaKH} | Họ tên: {HoTen} | ĐT: {DienThoai} | Địa chỉ: {DiaChi}";
        }
    }

}
