﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DanhSachKhachHangApp
{
    public partial class Form1 : Form
    {
        // Danh sách khách hàng dạng List (Generic)
        private List<KhachHang> danhSachKH = new List<KhachHang>();

        public Form1()
        {
            InitializeComponent();
        }

        // Sự kiện khi bấm nút Nạp khách hàng
        private void btnNapKhachHang_Click(object sender, EventArgs e)
        {
            // Xóa dữ liệu cũ (nếu có)
            danhSachKH.Clear();

            // Thêm dữ liệu mẫu
            danhSachKH.Add(new KhachHang { MaKH = "KH01", HoTen = "Nguyễn Văn A", DienThoai = "0901234567", DiaChi = "Hà Nội" });
            danhSachKH.Add(new KhachHang { MaKH = "KH02", HoTen = "Trần Thị B", DienThoai = "0912345678", DiaChi = "TP.HCM" });
            danhSachKH.Add(new KhachHang { MaKH = "KH03", HoTen = "Lê Văn C", DienThoai = "0987654321", DiaChi = "Đà Nẵng" });

            // Hiển thị lên ListBox
            HienThiDanhSach();
        }

        private void HienThiDanhSach()
        {
            lstKhachHang.Items.Clear();
            foreach (var kh in danhSachKH)
            {
                lstKhachHang.Items.Add(kh.ToString());
            }
        }

        
    }
}

