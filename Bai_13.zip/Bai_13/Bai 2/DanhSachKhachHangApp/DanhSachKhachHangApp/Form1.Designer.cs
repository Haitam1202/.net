﻿namespace DanhSachKhachHangApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstKhachHang = new System.Windows.Forms.ListBox();
            this.btnNapKhachHang = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstKhachHang
            // 
            this.lstKhachHang.FormattingEnabled = true;
            this.lstKhachHang.ItemHeight = 16;
            this.lstKhachHang.Location = new System.Drawing.Point(31, 22);
            this.lstKhachHang.Name = "lstKhachHang";
            this.lstKhachHang.Size = new System.Drawing.Size(710, 276);
            this.lstKhachHang.TabIndex = 0;
            // 
            // btnNapKhachHang
            // 
            this.btnNapKhachHang.Location = new System.Drawing.Point(159, 333);
            this.btnNapKhachHang.Name = "btnNapKhachHang";
            this.btnNapKhachHang.Size = new System.Drawing.Size(183, 69);
            this.btnNapKhachHang.TabIndex = 1;
            this.btnNapKhachHang.Text = "Nhập Khách Hàng";
            this.btnNapKhachHang.UseVisualStyleBackColor = true;
            this.btnNapKhachHang.Click += new System.EventHandler(this.btnNapKhachHang_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnNapKhachHang);
            this.Controls.Add(this.lstKhachHang);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstKhachHang;
        private System.Windows.Forms.Button btnNapKhachHang;
    }
}

