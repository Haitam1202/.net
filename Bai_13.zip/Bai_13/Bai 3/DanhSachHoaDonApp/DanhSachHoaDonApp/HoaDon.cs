﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DanhSachHoaDonApp
{
    public class HoaDon
    {
        public string MaHD { get; set; }
        public DateTime NgayLap { get; set; }
        public string TenKhachHang { get; set; }
        public double TongTien { get; set; }

        public override string ToString()
        {
            return $"Mã HD: {MaHD} | Ngày: {NgayLap:dd/MM/yyyy} | KH: {TenKhachHang} | Tổng: {TongTien:N0}đ";
        }
    }

}
