﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DanhSachHoaDonApp
{
    public partial class Form1 : Form
    {
        // Danh sách hóa đơn kiểu Generic
        private List<HoaDon> danhSachHD = new List<HoaDon>();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnNapHoaDon_Click(object sender, EventArgs e)
        {
            // Xóa danh sách cũ nếu có
            danhSachHD.Clear();

            // Thêm dữ liệu mẫu
            danhSachHD.Add(new HoaDon { MaHD = "HD001", NgayLap = new DateTime(2024, 5, 10), TenKhachHang = "Nguyễn Văn A", TongTien = 1500000 });
            danhSachHD.Add(new HoaDon { MaHD = "HD002", NgayLap = new DateTime(2024, 6, 1), TenKhachHang = "Trần Thị B", TongTien = 3200000 });
            danhSachHD.Add(new HoaDon { MaHD = "HD003", NgayLap = DateTime.Now, TenKhachHang = "Lê Văn C", TongTien = 890000 });

            // Hiển thị lên giao diện
            HienThiDanhSach();
        }

        private void HienThiDanhSach()
        {
            lstHoaDon.Items.Clear();
            foreach (var hd in danhSachHD)
            {
                lstHoaDon.Items.Add(hd.ToString());
            }
        }

       
    }
}

