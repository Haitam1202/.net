﻿using System;
using System.Data;
using System.Windows.Forms;
using QLKhachHang.BUS;



namespace GUI
{
    public partial class FormKhachHang : Form
    {
        KhachHangBUS bus = new KhachHangBUS();

        public FormKhachHang()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                bus.Them(txtTenKH.Text, txtDiaChi.Text, txtDienThoai.Text);
                MessageBox.Show("Thêm khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                bus.Sua(maKH, txtTenKH.Text, txtDiaChi.Text, txtDienThoai.Text);
                MessageBox.Show("Sửa khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                bus.Xoa(maKH);
                MessageBox.Show("Xóa khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                dgvKH.DataSource = bus.TimKiem(maKH);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            try
            {
                bus.Them(txtTenKH.Text, txtDiaChi.Text, txtDienThoai.Text);
                MessageBox.Show("Thêm khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }


        private void btnSua_Click_1(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                bus.Sua(maKH, txtTenKH.Text, txtDiaChi.Text, txtDienThoai.Text);
                MessageBox.Show("Sửa khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }


        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                bus.Xoa(maKH);
                MessageBox.Show("Xóa khách hàng thành công!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }


        private void btnTim_Click_1(object sender, EventArgs e)
        {
            try
            {
                int maKH = int.Parse(txtMaKH.Text);
                dgvKH.DataSource = bus.TimKiem(maKH);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

    }
}
