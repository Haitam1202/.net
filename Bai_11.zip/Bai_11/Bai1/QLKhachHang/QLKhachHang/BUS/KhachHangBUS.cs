﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLKhachHang.BUS
{
    public class KhachHangBUS
    {
        KhachHangDAL dal = new KhachHangDAL();

        public void Them(string ten, string diaChi, string dienThoai) => dal.ThemKhachHang(ten, diaChi, dienThoai);
        public void Sua(int maKH, string ten, string diaChi, string dienThoai) => dal.SuaKhachHang(maKH, ten, diaChi, dienThoai);
        public void Xoa(int maKH) => dal.XoaKhachHang(maKH);
        public DataTable TimKiem(int maKH) => dal.TimKiemKhachHang(maKH);
    }

}
