﻿using System.Data;
using System.Data.SqlClient;

public class KhachHangDAL
{
    SqlConnection conn = new SqlConnection(
    "Data Source=localhost\\MSSQLSERVER02;Initial Catalog=KhachHangDB;Integrated Security=True"
);


    public void ThemKhachHang(string ten, string diaChi, string dienThoai)
    {
        SqlCommand cmd = new SqlCommand("sp_ThemKhachHang", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@TenKH", ten);
        cmd.Parameters.AddWithValue("@DiaChi", diaChi);
        cmd.Parameters.AddWithValue("@DienThoai", dienThoai);
        conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
    }

    public void SuaKhachHang(int maKH, string ten, string diaChi, string dienThoai)
    {
        SqlCommand cmd = new SqlCommand("sp_SuaKhachHang", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@MaKH", maKH);
        cmd.Parameters.AddWithValue("@TenKH", ten);
        cmd.Parameters.AddWithValue("@DiaChi", diaChi);
        cmd.Parameters.AddWithValue("@DienThoai", dienThoai);
        conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
    }

    public void XoaKhachHang(int maKH)
    {
        SqlCommand cmd = new SqlCommand("sp_XoaKhachHang", conn);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@MaKH", maKH);
        conn.Open(); cmd.ExecuteNonQuery(); conn.Close();
    }

    public DataTable TimKiemKhachHang(int maKH)
    {
        SqlDataAdapter da = new SqlDataAdapter("sp_TimKiemKhachHang", conn);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.AddWithValue("@MaKH", maKH);
        DataTable dt = new DataTable();
        da.Fill(dt);
        return dt;
    }
}
