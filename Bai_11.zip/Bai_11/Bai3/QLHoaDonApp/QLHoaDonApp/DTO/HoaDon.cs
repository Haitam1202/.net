﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLHoaDonApp.DTO
{
    public class HoaDon
    {
        public string MaHD { get; set; }
        public DateTime NgayLap { get; set; }
        public string MaKH { get; set; }
        public decimal TongTien { get; set; }
    }
}

