﻿using QLHoaDonApp.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace QLHoaDonApp.DAL
{
    public class HoaDonDAL
    {
        public static List<HoaDon> LayTatCa()
        {
            List<HoaDon> ds = new List<HoaDon>();
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_LayTatCaHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    HoaDon hd = new HoaDon
                    {
                        MaHD = reader["MaHD"].ToString(),
                        NgayLap = Convert.ToDateTime(reader["NgayLap"]),
                        MaKH = reader["MaKH"].ToString(),
                        TongTien = Convert.ToDecimal(reader["TongTien"])
                    };
                    ds.Add(hd);
                }
            }
            return ds;
        }

        public static void Them(HoaDon hd)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_ThemHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHD", hd.MaHD);
                cmd.Parameters.AddWithValue("@NgayLap", hd.NgayLap);
                cmd.Parameters.AddWithValue("@MaKH", hd.MaKH);
                cmd.Parameters.AddWithValue("@TongTien", hd.TongTien);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void Sua(HoaDon hd)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_SuaHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHD", hd.MaHD);
                cmd.Parameters.AddWithValue("@NgayLap", hd.NgayLap);
                cmd.Parameters.AddWithValue("@MaKH", hd.MaKH);
                cmd.Parameters.AddWithValue("@TongTien", hd.TongTien);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void Xoa(string maHD)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_XoaHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHD", maHD);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static HoaDon Tim(string maHD)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_TimHoaDon", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHD", maHD);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new HoaDon
                    {
                        MaHD = reader["MaHD"].ToString(),
                        NgayLap = Convert.ToDateTime(reader["NgayLap"]),
                        MaKH = reader["MaKH"].ToString(),
                        TongTien = Convert.ToDecimal(reader["TongTien"])
                    };
                }
                return null;
            }
        }
    }
}
