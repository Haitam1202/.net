﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using QLHoaDonApp.DAL;
using QLHoaDonApp.DTO;



namespace QLHoaDonApp.GUI
{
    public partial class FormHoaDon : Form
    {
        public FormHoaDon()
        {
            InitializeComponent();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            HoaDon hd = new HoaDon
            {
                MaHD = txtMaHD.Text,
                NgayLap = dtpNgayLap.Value,
                MaKH = txtMaKH.Text,
                TongTien = decimal.Parse(txtTongTien.Text)
            };

            HoaDonDAL.Them(hd);
            MessageBox.Show("Đã thêm hóa đơn.");
            LoadData();
        }


        private void btnSua_Click(object sender, EventArgs e)
        {
            HoaDon hd = new HoaDon
            {
                MaHD = txtMaHD.Text,
                NgayLap = dtpNgayLap.Value,
                MaKH = txtMaKH.Text,
                TongTien = decimal.Parse(txtTongTien.Text)
            };

            HoaDonDAL.Sua(hd);
            MessageBox.Show("Đã cập nhật hóa đơn.");
            LoadData();
        }


        private void btnXoa_Click(object sender, EventArgs e)
        {
            string maHD = txtMaHD.Text;

            HoaDonDAL.Xoa(maHD);
            MessageBox.Show("Đã xóa hóa đơn.");
            LoadData();
        }


        private void btnTim_Click(object sender, EventArgs e)
        {
            string maHD = txtMaHD.Text;

            HoaDon hd = HoaDonDAL.Tim(maHD);
            if (hd != null)
            {
                dtpNgayLap.Value = hd.NgayLap;
                txtMaKH.Text = hd.MaKH;
                txtTongTien.Text = hd.TongTien.ToString();
            }
            else
            {
                MessageBox.Show("Không tìm thấy hóa đơn.");
            }
        }

        private void LoadData()
        {
            dgvHoaDon.DataSource = HoaDonDAL.LayTatCa();
        }

        private void FormHoaDon_Load(object sender, EventArgs e)
        {
            LoadData();
        }

    }
}
