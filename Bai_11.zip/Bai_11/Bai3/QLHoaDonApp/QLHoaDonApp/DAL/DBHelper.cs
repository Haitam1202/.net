﻿using System.Data.SqlClient;

namespace QLHoaDonApp.DAL
{
    public class DBHelper
    {
        private static string connectionString = @"Data Source=localhost\MSSQLSERVER02;Initial Catalog=QLHoaDon;Integrated Security=True";
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
