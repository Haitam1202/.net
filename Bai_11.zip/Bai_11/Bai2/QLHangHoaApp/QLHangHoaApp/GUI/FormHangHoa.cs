﻿using QLHangHoaApp.DAL;
using QLHangHoaApp.DTO;
using System;
using System.Windows.Forms;

namespace QLHangHoaApp.GUI
{
    public partial class FormHangHoa : Form
    {
        public FormHangHoa()
        {
            InitializeComponent();
        }

        private void LoadData()
        {
            dgvHangHoa.DataSource = HangHoaDAL.LayTatCa();
        }

        private void FormHangHoa_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            HangHoa hh = new HangHoa
            {
                MaHang = txtMaHang.Text,
                TenHang = txtTenHang.Text,
                SoLuong = int.Parse(txtSoLuong.Text),
                DonGia = decimal.Parse(txtDonGia.Text)
            };
            HangHoaDAL.Them(hh);
            LoadData();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            HangHoa hh = new HangHoa
            {
                MaHang = txtMaHang.Text,
                TenHang = txtTenHang.Text,
                SoLuong = int.Parse(txtSoLuong.Text),
                DonGia = decimal.Parse(txtDonGia.Text)
            };
            HangHoaDAL.Sua(hh);
            LoadData();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            HangHoaDAL.Xoa(txtMaHang.Text);
            LoadData();
        }

        private void btnTim_Click(object sender, EventArgs e)
        {
            HangHoa hh = HangHoaDAL.Tim(txtMaHang.Text);
            if (hh != null)
            {
                txtTenHang.Text = hh.TenHang;
                txtSoLuong.Text = hh.SoLuong.ToString();
                txtDonGia.Text = hh.DonGia.ToString();
            }
            else
            {
                MessageBox.Show("Không tìm thấy!");
            }
        }

        private void btnThem_Click_1(object sender, EventArgs e)
        {
            HangHoa hh = new HangHoa
            {
                MaHang = txtMaHang.Text,
                TenHang = txtTenHang.Text,
                SoLuong = int.Parse(txtSoLuong.Text),
                DonGia = decimal.Parse(txtDonGia.Text)
            };

            HangHoaDAL.Them(hh);
            MessageBox.Show("Thêm thành công!");
            LoadData(); // Hàm này bạn nên có để cập nhật DataGridView
        }


        private void btnSua_Click_1(object sender, EventArgs e)
        {
            HangHoa hh = new HangHoa
            {
                MaHang = txtMaHang.Text,
                TenHang = txtTenHang.Text,
                SoLuong = int.Parse(txtSoLuong.Text),
                DonGia = decimal.Parse(txtDonGia.Text)
            };

            HangHoaDAL.Sua(hh);
            MessageBox.Show("Cập nhật thành công!");
            LoadData();
        }


        private void btnXoa_Click_1(object sender, EventArgs e)
        {
            string maHang = txtMaHang.Text;

            HangHoaDAL.Xoa(maHang);
            MessageBox.Show("Xóa thành công!");
            LoadData();
        }


        private void btnTim_Click_1(object sender, EventArgs e)
        {
            string maHang = txtMaHang.Text;

            HangHoa hh = HangHoaDAL.Tim(maHang);

            if (hh != null)
            {
                txtTenHang.Text = hh.TenHang;
                txtSoLuong.Text = hh.SoLuong.ToString();
                txtDonGia.Text = hh.DonGia.ToString();
            }
            else
            {
                MessageBox.Show("Không tìm thấy mã hàng!");
            }
        }

    }
}
