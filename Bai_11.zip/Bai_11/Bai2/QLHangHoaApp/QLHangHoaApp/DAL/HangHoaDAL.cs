﻿using QLHangHoaApp.DTO;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace QLHangHoaApp.DAL
{
    public class HangHoaDAL
    {
        public static List<HangHoa> LayTatCa()
        {
            List<HangHoa> ds = new List<HangHoa>();
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_LayTatCaHangHoa", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    HangHoa hh = new HangHoa
                    {
                        MaHang = reader["MaHang"].ToString(),
                        TenHang = reader["TenHang"].ToString(),
                        SoLuong = (int)reader["SoLuong"],
                        DonGia = (decimal)reader["DonGia"]
                    };
                    ds.Add(hh);
                }
            }
            return ds;
        }

        public static void Them(HangHoa hh)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_ThemHangHoa", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHang", hh.MaHang);
                cmd.Parameters.AddWithValue("@TenHang", hh.TenHang);
                cmd.Parameters.AddWithValue("@SoLuong", hh.SoLuong);
                cmd.Parameters.AddWithValue("@DonGia", hh.DonGia);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void Sua(HangHoa hh)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_SuaHangHoa", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHang", hh.MaHang);
                cmd.Parameters.AddWithValue("@TenHang", hh.TenHang);
                cmd.Parameters.AddWithValue("@SoLuong", hh.SoLuong);
                cmd.Parameters.AddWithValue("@DonGia", hh.DonGia);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void Xoa(string maHang)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_XoaHangHoa", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHang", maHang);
                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static HangHoa Tim(string maHang)
        {
            using (SqlConnection conn = DBHelper.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("sp_TimHangHoa", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaHang", maHang);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new HangHoa
                    {
                        MaHang = reader["MaHang"].ToString(),
                        TenHang = reader["TenHang"].ToString(),
                        SoLuong = (int)reader["SoLuong"],
                        DonGia = (decimal)reader["DonGia"]
                    };
                }
            }
            return null;
        }
    }
}
