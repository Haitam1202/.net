﻿using System.Data.SqlClient;

namespace QLHangHoaApp.DAL
{
    public class DBHelper
    {
        // Nếu bạn dùng SQL Server mặc định (giống như hình bạn đang dùng: MSSQLSERVER02)
        private static string connectionString = @"Data Source=localhost\MSSQLSERVER02;Initial Catalog=QLHangHoa;Integrated Security=True";


        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
