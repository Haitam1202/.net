﻿using System;

class Diem
{
    // Thuộc tính tọa độ
    public double X { get; set; }
    public double Y { get; set; }

    // Constructor
    public Diem(double x, double y)
    {
        X = x;
        Y = y;
    }

    // Phương thức tính khoảng cách đến 1 điểm khác
    public double TinhKhoangCach(Diem d2)
    {
        double dx = this.X - d2.X;
        double dy = this.Y - d2.Y;
        return Math.Sqrt(dx * dx + dy * dy); // Công thức khoảng cách Euclid
    }
}
class Program
{
    static void Main()
    {
        // Nhập điểm thứ nhất
        Console.Write("Nhập tọa độ X1: ");
        double x1 = double.Parse(Console.ReadLine());
        Console.Write("Nhập tọa độ Y1: ");
        double y1 = double.Parse(Console.ReadLine());

        // Nhập điểm thứ hai
        Console.Write("Nhập tọa độ X2: ");
        double x2 = double.Parse(Console.ReadLine());
        Console.Write("Nhập tọa độ Y2: ");
        double y2 = double.Parse(Console.ReadLine());

        // Tạo hai đối tượng điểm
        Diem d1 = new Diem(x1, y1);
        Diem d2 = new Diem(x2, y2);

        // Tính và hiển thị khoảng cách
        double kc = d1.TinhKhoangCach(d2);
        Console.WriteLine($"\nKhoảng cách giữa 2 điểm là: {kc:F2}");

        Console.ReadLine(); // Dừng màn hình console
    }
}
