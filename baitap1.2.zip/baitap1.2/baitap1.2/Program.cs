﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;

        // Nhập chiều cao
        Console.Write("Nhập chiều cao (h): ");
        double chieuCao = double.Parse(Console.ReadLine());

        // Nhập bán kính đáy
        Console.Write("Nhập bán kính đáy (r): ");
        double banKinh = double.Parse(Console.ReadLine());

        // Tính toán
        double dienTichXungQuanh = 2 * Math.PI * banKinh * chieuCao;
        double theTich = Math.PI * banKinh * banKinh * chieuCao;

        // Hiển thị kết quả
        Console.WriteLine("\n-- KẾT QUẢ --");
        Console.WriteLine("Diện tích xung quanh: " + dienTichXungQuanh);
        Console.WriteLine("Thể tích hình trụ: " + theTich);
    }
}
