﻿using System;

class Program
{
    static void Main()
    {
        double a, b, c;

        Console.Write("Nhập cạnh a: ");
        a = double.Parse(Console.ReadLine());

        Console.Write("Nhập cạnh b: ");
        b = double.Parse(Console.ReadLine());

        Console.Write("Nhập cạnh c: ");
        c = double.Parse(Console.ReadLine());

        // Kiểm tra điều kiện tồn tại tam giác
        if (a > 0 && b > 0 && c > 0 &&
            a + b > c && a + c > b && b + c > a)
        {
            Console.WriteLine("Ba cạnh ({0}, {1}, {2}) là một tam giác.", a, b, c);

            // Tam giác đều
            if (a == b && b == c)
            {
                Console.WriteLine("Đây là tam giác đều.");
            }
            // Tam giác cân
            else if (a == b || b == c || a == c)
            {
                Console.WriteLine("Đây là tam giác cân.");
            }
            // Tam giác vuông
            else if (IsRightTriangle(a, b, c))
            {
                Console.WriteLine("Đây là tam giác vuông.");
            }
            else
            {
                Console.WriteLine("Đây là tam giác thường.");
            }
        }
        else
        {
            Console.WriteLine("Ba cạnh không tạo thành một tam giác.");
        }

        Console.ReadLine(); // Giữ console mở
    }

    // Hàm kiểm tra tam giác vuông
    static bool IsRightTriangle(double x, double y, double z)
    {
        // Kiểm tra theo định lý Pythagore
        return Math.Abs(x * x + y * y - z * z) < 0.0001 ||
               Math.Abs(x * x + z * z - y * y) < 0.0001 ||
               Math.Abs(y * y + z * z - x * x) < 0.0001;
    }
}
